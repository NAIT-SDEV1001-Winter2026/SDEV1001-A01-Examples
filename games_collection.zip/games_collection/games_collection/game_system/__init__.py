"""Game collection package."""
