from pathlib import Path

#relative imports from within this package
from .utilities.collection import Collection
from .utilities.game import Game

#keep prompting until a non empty value is entered
def get_non_empty_input(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("Input cannot be empty. Please try again.")

#keep prompting until a positive integer is entered
def get_positive_int(prompt):
    while True:
        user_input = input(prompt)
        try:
            value = int(user_input)
            if value <= 0:
                print("Please enter a whole number greater than 0.")
                continue#go to next iteration of the loop(prompt again)
            return value#return the positive integer
        except ValueError:#if int() fails
            print("Invalid input. Please enter a whole number.")

#keep prompting until a positive float is entered
def get_non_negative_float(prompt):
    while True:
        user_input = input(prompt)
        try:
            value = float(user_input)
            if value < 0:
                print("Please enter a number that is 0 or greater.")
                continue#go to next iteration of the loop(prompt again)
            return round(value, 2)#return the positive float
        except ValueError:#if (float) fails
            print("Invalid input. Please enter a valid price.")

#Display the menu
def show_menu():
    print("\n=== Game Collection Menu ===")
    print("1. Add new game")
    print("2. Read games from csv file")
    print("3. Write games to csv file")
    print("4. List all game titles")
    print("5. Display total collection value")
    print("6. Remove game by title")
    print("7. Quit")

#main guard (if this py file is imported, it will only run the functions above)
if __name__ == "__main__":
    current_path = Path.cwd()#where am I now?
    print("Game Collection Package")    
    #the csv file will be in the top folder (one folder up from the package)
    file_path = current_path / "game_collection.csv"

    #get valid collection values
    owner = get_non_empty_input("Enter the collection owner's name: ")
    console = get_non_empty_input("Enter the console/platform: ")

    #Create the collection object
    collection = Collection(owner, console)
          
    while True:
        show_menu()

        choice = input("Choose an option: ").strip()

        if choice == "1":            
                title = get_non_empty_input("Enter game title: ")
                max_players = get_positive_int("Enter maximum number of players: ")
                price = get_non_negative_float("Enter price: $")
                collection.add_game(Game(title, max_players, price))
                print(f"Added {title}.")            

        elif choice == "2":            
                collection.read_games_from_file(file_path)                
            
        elif choice == "3":         
                collection.write_games_to_csv(file_path)
                print(f"Wrote {len(collection.games)} game(s) to {file_path.name}.")         

        elif choice == "4":
            collection.list_game_titles()           

        elif choice == "5":
            print(f"Total collection value: ${collection.get_total_value():.2f}")

        elif choice == "6":
            title = get_non_empty_input("Enter the title of the game to remove: ")

            if collection.remove_game(title):
                print(f"Removed {title}.")
            else:
                print("Game not found.")

        elif choice == "7":
            print("Goodbye!")
            break        
          
        else:
            print("Invalid menu choice. Please select 1 to 7.")




