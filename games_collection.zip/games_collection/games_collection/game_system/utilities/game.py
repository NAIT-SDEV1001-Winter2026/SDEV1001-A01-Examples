
class Game:
    def __init__(self, title, max_players, price):
        title = title.strip()
        try:
            max_players = int(max_players)
        except (ValueError):
            print("Maximum players must be a whole number.")       
        try:
            price = float(price)
        except (ValueError):
            print("Price must be a number.")        

        self.title = title
        self.max_players = max_players
        self.price = price

    def __str__(self):
        return f"{self.title} maximum players is {self.max_players}"

    def __repr__(self):
        return f"{self.title} maximum players is {self.max_players}"
