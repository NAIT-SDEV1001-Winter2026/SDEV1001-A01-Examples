
from csv import DictReader, DictWriter
from pathlib import Path

#from within the current package utilities, find game module ()
from .game import Game


class Collection:
    def __init__(self, owner, console):
        
        self.owner = owner
        self.console = console
        self.games = []

    def __str__(self):
        return f"{self.owner} has {len(self.games)} games"

    def __repr__(self):
        return f"{self.owner} has {len(self.games)} games"

    def add_game(self, game: Game):
        self.games.append(game)

    #remove game by title
    #if game is not found, return False, otherwise return True
    def remove_game(self, game_title):
        return_value = False
        search_title = game_title.strip().lower()
        for game in self.games:
            if game.title.lower() == search_title:
                self.games.remove(game)
                return_value =  True
        return return_value

    def write_games_to_csv(self, file_path):
        if len(self.games) == 0:
            print("There are no games to write to the file")
        else:
            with open(file_path, "w", newline="") as file:
                writer = DictWriter(file, fieldnames=["title", "max_players", "price"])
                writer.writeheader()
                for game in self.games:
                    writer.writerow(
                        {
                            "title": game.title,
                            "max_players": game.max_players,
                            "price": f"{game.price:.2f}",
                        }
                    )

    def read_games_from_file(self, file_path):    
        self.games = []
        try:
            with open(file_path, "r", newline="") as file:
                reader = DictReader(file)
                for row in reader:
                    if not row:#optional but if there is an empty row on the file then skip it
                        continue
                    self.games.append(
                        Game(
                            row["title"],
                            int(row["max_players"]),#casting is optional but if you want to use as number later then you don't have to cast it then
                            float(row["price"]),
                        )
                    )
        except FileNotFoundError:
            print(f"⚠️ File not found: {file_path}")
            
    
    def get_total_value(self):
        total_value = 0
        for game in self.games:
            total_value += game.price
        return round(total_value, 2)

    def list_game_titles(self):
         if len(self.games) == 0:
            print("There are no games in the collection.")
         else:
            print("Games in collection:")
            for game in self.games:
                print(f"- {game.title}")        
          
 