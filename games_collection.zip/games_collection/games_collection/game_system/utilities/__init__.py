"""Utility classes for the game collection package."""

from .game import Game
from .collection import Collection

__all__ = ["Game", "Collection"]
